let tagCountMap = {
    "apache-kafka": 3,
    "android-studio": 3,
    "integration": 2,
    "jsp": 2,
    "code-generation": 1,
    "jaxb": 1,
    "dart": 1,
    "selenium": 1,
};